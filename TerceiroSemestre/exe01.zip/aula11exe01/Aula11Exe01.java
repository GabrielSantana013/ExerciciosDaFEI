/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula11exe01;

import view.JanelaCadastro;

/**
 *
 * @author unifgdias
 */
public class Aula11Exe01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        JanelaCadastro j = new JanelaCadastro();
        j.setVisible(true);
        
    }
    
}
