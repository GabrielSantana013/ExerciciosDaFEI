/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import model.Cadastra;
import model.ProcuraUsuario;
import model.Usuario;
import view.JanelaCadastro;
import view.JanelaProcuraUsuario;

/**
 *
 * @author unifgdias
 */
public class Control {
    
    private JanelaCadastro jCadastro;
    private JanelaProcuraUsuario jProcuraUsuario;
    ArrayList<Usuario> cadastro = new ArrayList<>();

    public Control(JanelaCadastro jCadastro) {
        this.jCadastro = jCadastro;
        
    }
    
    public Control(JanelaProcuraUsuario jProcuraUsuario){
        this.jProcuraUsuario = jProcuraUsuario;
    }
    
    public void controlCadastrar(){
        
        String nome = jCadastro.getjTextField1().getText();
        String sobrenome = jCadastro.getjTextField2().getText();
        String CPF = jCadastro.getjTextField3().getText();
        int idade = Integer.parseInt(jCadastro.getjTextField4().getText());
        String sexo = "";
        if(jCadastro.getjRadioButton1().isSelected())
        {
            sexo = "Masculino";        
        }
        else if(jCadastro.getjRadioButton2().isSelected()){
            sexo = "Feminino";        
        }
        
        Cadastra c = new Cadastra();
        cadastro.add(c.cadastrar(nome, sobrenome, CPF, idade, sexo));
         for(Usuario u: cadastro){
            System.out.println(u);
        }
        
    }
    
    public void controlProcurar(){
        System.out.println(cadastro);
        ProcuraUsuario pU = new ProcuraUsuario(); 
        String CPF = jProcuraUsuario.getjTextField1().getText();
        for(Usuario u: cadastro){
            System.out.println(u);
        }
        int userIndex = pU.procuraUsuario(CPF, cadastro);
        
        if(userIndex == -1){
            jProcuraUsuario.getjTextField2().setText("Usuário não encontrado");
        }
        else{
            Usuario u = cadastro.get(userIndex);
            jProcuraUsuario.getjTextField2().setText("Usuario" + u.getNome() + "\n"
            + "CPF" + u.getCpf());
        }
    }
    
}
