/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author unifgdias
 */
public class Cadastra {
        
    public Usuario cadastrar(String nome, String sobrenome,String CPF, int idade, String sexo){
           
        Usuario u1 = new Usuario(nome, sobrenome, CPF, idade, sexo);
        System.out.println(u1);
        return u1;
                
    }
    
}
