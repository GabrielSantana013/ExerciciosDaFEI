/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author unifgdias
 */
public class ProcuraUsuario {
    
    public int procuraUsuario(String CPF, ArrayList<Usuario> cadastro){        
        
        System.out.println("xxxx");
        for(Usuario u: cadastro){
            System.out.println(u);
        }
        for(int i = 0; i < cadastro.size(); i++){
            if(cadastro.get(i).getCpf().equals(CPF)){
                return i;
            }
        }        
        return -1;        
    }

}
