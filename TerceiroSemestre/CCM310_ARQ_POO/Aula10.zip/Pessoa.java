/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula10exe01;

import static aula10exe01.CpfException.CpfValidator;

/**
 *
 * @author unifgdias
 */

public class Pessoa {

    private String name, lastName, CPF;
    private int age;

    public Pessoa(){}
    
    public Pessoa(String name, String lastName, String CPF, int age) throws CpfException{
        this.name = name;
        this.lastName = lastName;        
        this.CPF = CpfValidator(CPF);
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "\nNome:" + getName()+ 
                "\nSobrenome:" + getLastName() +
                "\nIdade: " + getAge() + 
                "\nCPF: " + getCPF();
        
    }
    
    
    
     
}
