/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula10exe01;

/**
 *
 * @author unifgdias
 */

class CpfException extends Exception{

    public CpfException(String message) {
        super(message);
    }
    
    public static String CpfValidator(String CPF) throws CpfException{
        
            if(CPF.contains(".") || CPF.contains("-")){                
                throw new CpfException("CPF inválido");
            }
            else{
                return CPF;
            }
        } 
}
