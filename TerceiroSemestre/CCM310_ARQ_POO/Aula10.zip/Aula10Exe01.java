/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula10exe01;

import java.util.Scanner;

/**
 *
 * @author unifgdias
 */
public class Aula10Exe01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        
                    
            Pessoa p = new Pessoa();
            System.out.println("Digite seu nome: ");
            String name = sc.nextLine();            
            System.out.println("Digite seu sobrenome: ");
            String lastName = sc.nextLine();                                
            System.out.println("Digite sua idade: ");
            int age = sc.nextInt(); 
            sc.nextLine();              
            while(true){
                try{            
                    System.out.println("Digite seu CPF: ");
                    String CPF = sc.nextLine();   
                    p = new Pessoa(name, lastName, CPF, age);
                    break;
                }
                catch(CpfException e){        
                        System.out.println(e.getMessage());
                        continue;
                }            
           }
        System.out.println(p);
        sc.close();
    }
    
}
