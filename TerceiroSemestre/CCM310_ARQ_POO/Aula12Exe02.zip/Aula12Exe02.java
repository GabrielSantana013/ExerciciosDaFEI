/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula12exe02;

/**
 *
 * @author unifgdias
 */
public class Aula12Exe02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Janela j = new Janela();
        j.setVisible(true);
    }
    
}
